package com.example.sharedprefexampletwo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v4.app.NavUtils;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Button btnGetSharedPref = (Button) findViewById(R.id.btnGetSharedPref);
        btnGetSharedPref.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					//Get a context for the first app
					Context myContext = getApplicationContext().createPackageContext("com.cr.sharedprefexampleone",
							Context.MODE_WORLD_WRITEABLE);
					//Get the shared preferences using the context of the first app
					SharedPreferences testPrefs = myContext.getSharedPreferences 
							("sharedprefone", Context.MODE_WORLD_READABLE);
					String prefString = testPrefs.getString("time", "Couldn't find");
					TextView textView1 = (TextView) findViewById(R.id.textView1);
					textView1.setText("GET: "+prefString);
				} catch (Exception e) {
					e.printStackTrace();
					Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_SHORT).show();
				} 
				
			}
		});
       
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}
