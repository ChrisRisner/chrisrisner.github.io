package com.cr.sharedprefexampleone;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.support.v4.app.NavUtils;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
                
        Button btnSetSharedPref = (Button)findViewById(R.id.btnSetSharedPref);
        btnSetSharedPref.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				SharedPreferences prefs = getApplicationContext().
						getSharedPreferences("sharedprefone", Context.MODE_WORLD_READABLE);
				Editor edit = prefs.edit();
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date date = new Date();			//	
				edit.putString("time", dateFormat.format(date));
				TextView textView1 = (TextView) findViewById(R.id.textView1);				
				textView1.setText("SET:" + dateFormat.format(date));
				edit.commit();				
			}
		});
        
        Button btnGetSharedPref = (Button)findViewById(R.id.btnGetSharedPref);
        btnGetSharedPref.setOnClickListener(new OnClickListener() {
			//
			@Override
			public void onClick(View v) {
				SharedPreferences prefs = getApplicationContext().getSharedPreferences("sharedprefone", Context.MODE_WORLD_READABLE);
				String pref = prefs.getString("time", "Could not get");
				TextView textView1 = (TextView) findViewById(R.id.textView1);
				textView1.setText("GET:" + pref);
			}
		});        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}
