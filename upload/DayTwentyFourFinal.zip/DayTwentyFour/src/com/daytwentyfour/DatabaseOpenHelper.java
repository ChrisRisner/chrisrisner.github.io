package com.daytwentyfour;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseOpenHelper extends SQLiteOpenHelper {

	private final static  String databaseName = "DayTwentyFourDb";
	private final static int    databaseVersion = 1;
	
	public DatabaseOpenHelper(Context context) {
		super(context, databaseName, null, databaseVersion);
	}

	@Override
	public void onCreate(SQLiteDatabase sqLiteDB) {
		String createSql = "CREATE TABLE DayTwentyFour " +
				"(_id integer primary key autoincrement, " + 
				"name text not null);";
		sqLiteDB.execSQL(createSql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase sqLiteDB, int oldVersion, int newVersion) {
		sqLiteDB.execSQL("DROP TABLE IF EXISTS DayTwentyFour");
		onCreate(sqLiteDB);
	}
}
