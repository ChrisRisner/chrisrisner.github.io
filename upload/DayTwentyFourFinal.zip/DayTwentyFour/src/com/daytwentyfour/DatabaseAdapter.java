package com.daytwentyfour;

import java.util.ArrayList;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class DatabaseAdapter {

	private Context context;
	private SQLiteDatabase database;
	private DatabaseOpenHelper dbHelper;
	
	public DatabaseAdapter(Context context) {
		this.context = context;
	}
	
	public DatabaseAdapter open() throws SQLException {
		dbHelper = new DatabaseOpenHelper(context);
		database = dbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		dbHelper.close();
	}
	
	
	public long createRecord(String text) {
		ContentValues contentValue = new ContentValues();		
		contentValue.put("name", text);			
		return database.insert("DayTwentyFour", null, contentValue);
	}

	public boolean updateRecord(long rowId, String text) {
		ContentValues contentValue = new ContentValues();
		contentValue.put("name", text);
		return database.update("DayTwentyFour", contentValue, "_id =" + rowId, null) > 0;
	}

	public boolean deleteRecord(long rowId) {
		return database.delete("DayTwentyFour", "_id =" + rowId, null) > 0;
	}

	public ArrayList<String> fetchAllRecords() {
		Cursor cursor = database.query("DayTwentyFour", new String[] { "_id", "name"},
				null, null, null, null, null);		
		ArrayList<String> records = new ArrayList<String>();		
		cursor.moveToFirst();
		for (int i = 0; i < cursor.getCount(); i++) {			
			records.add(cursor.getString(1));		
			cursor.moveToNext();
		}
		cursor.close();
		return records;
	}

	public String fetchRecord(long rowId) throws SQLException {
		Cursor mCursor = database.query(true, "DayTwentyFour", new String[] { "_id",
				"name" }, "_id ="+ rowId, null, null, null, null, null);
		if (mCursor != null) {
			mCursor.moveToFirst();
			return (mCursor.getString(1));
		}
		return null;
	}
}
