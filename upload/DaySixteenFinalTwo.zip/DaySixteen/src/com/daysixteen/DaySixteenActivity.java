package com.daysixteen;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewDebug.FlagToString;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DaySixteenActivity extends BaseActivity {
	private TextView lblTextViewOne;
	private EditText editText1;
	public static int notificationId = 0;

	public static String MyStaticString;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);	
		Log.i("DaySixteenActivity", "onCreate Start");

		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);
		
		//Will handle removing the notification when the activity is called
		//String notificationService = Context.NOTIFICATION_SERVICE;
		//NotificationManager notificationManager = (NotificationManager) getSystemService(notificationService);			
		//notificationManager.cancel(1);
		
		
		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());
				
				String notificationService = Context.NOTIFICATION_SERVICE;
				NotificationManager notificationManager = (NotificationManager) getSystemService(notificationService);			
				 
				Notification notification = new Notification(R.drawable.ic_launcher, 
											"Hello Notification!", System.currentTimeMillis());
				
				
				Intent notificationIntent = new Intent(getApplicationContext(), DaySixteenActivity.class);
				PendingIntent contentIntent = PendingIntent.getActivity(getApplicationContext(), 0,
												notificationIntent, 0);
				notification.setLatestEventInfo(getApplicationContext(), "Notification Title", 
												"Notification Text", contentIntent);
				
				
				//notification.flags |= Notification.FLAG_AUTO_CANCEL; //Removes the notification when tapped
				//notification.defaults |= Notification.DEFAULT_SOUND;  //Will play the default sound
				//notification.sound = Uri.parse("file:///myfilepath/mysound.mp3"); //Will play mysound.mp3
				//notification.defaults |= Notification.DEFAULT_VIBRATE; //Will cause a vibration
				//long[] vibration = {0,100,100,100};//Creates a vibration array
				//notification.vibrate = vibration;//tells the notification to vibrate to a custom array
				//notification.defaults |= Notification.DEFAULT_LIGHTS;//show the default lights
				//notification.ledARGB = 0xffff0000;
				//notification.ledOnMS = 1000;
				//notification.ledOffMS = 1000;
				//notification.flags |= Notification.FLAG_SHOW_LIGHTS;
				
				notificationManager.notify(1, notification);
			}
		});		
		
		Log.i("DaySixTeenActivity", "onCreate End");
	}

}