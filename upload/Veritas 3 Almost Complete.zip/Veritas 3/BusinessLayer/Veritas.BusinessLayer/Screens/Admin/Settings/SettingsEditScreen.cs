﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Veritas.DataLayer.Models;
using Veritas.BusinessLayer.Caching;
using System.IO;
using System.Web;

namespace Veritas.BusinessLayer.Screens.Admin.Settings
{
    public class SettingsEditScreen : ScreenBase
    {
        //public BlogConfig BlogConfig { get; set; }

        public SettingsEditScreen()
        {
            LoadScreen();
        }

        protected override void LoadScreen()
        {
            //this.BlogConfig = repo.GetBlogConfigByBlogConfigId(this.blogConfig.BlogConfigId);
            CacheHandler.ResetCache();
            var pullConfigFresh = CacheHandler.GetBlogConfig();
        }

        public override bool IsValid
        {
            get 
            {
                if (this.blogConfig.ShowBlogAbout && string.IsNullOrEmpty(this.blogConfig.BlogAbout))
                    return false;
                if (this.blogConfig.PostsPerPage < 1)
                    return false;
                if (this.blogConfig.PostCount < 0)
                    return false;
                if (!string.IsNullOrEmpty(this.blogConfig.Skin) &&
                    !File.Exists(HttpContext.Current.Server.MapPath("..") + "/Content/Themes/" + this.blogConfig.Skin + ".css"))
                    return false;
                if (string.IsNullOrEmpty(this.blogConfig.Title))
                    return false;
                if (string.IsNullOrEmpty(this.blogConfig.SmtpServer))
                    return false;

                return true;
            }
        }

        public override Dictionary<string, string> GetValidationErrors()
        {
            Dictionary<string, string> items = new Dictionary<string, string>();


            if (this.blogConfig.ShowBlogAbout && string.IsNullOrEmpty(this.blogConfig.BlogAbout))
                items.Add("blogConfig.ShowBlogAbout", "Show Blog About is selected but the Blog About info is not filled in.");
            if (this.blogConfig.PostsPerPage < 1)
                items.Add("blogConfig.PostsPerPage", "The posts per page must be greater than 0.");
            if (this.blogConfig.PostCount < 0)
                items.Add("blogConfig.PostCount", "The post count must be zero or greater.");
            if (!string.IsNullOrEmpty(this.blogConfig.Skin) &&
                !File.Exists(HttpContext.Current.Server.MapPath("/content/themes/") + this.blogConfig.Skin + ".css"))
                items.Add("blogConfig.Skin", "You have chosen a skin that does not exist in themes.");
            if (string.IsNullOrEmpty(this.blogConfig.Title))
                items.Add("blogConfig.Title", "You must enter a blog title.");
            if (string.IsNullOrEmpty(this.blogConfig.SmtpServer))
                items.Add("blogConfig.SmtpServer", "You must enter a SMTP server for emails.");

            return items;
        }

        public void SaveConfig()
        {
            repo.Save();
        }
    }
}
