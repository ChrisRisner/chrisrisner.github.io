﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Veritas.BusinessLayer.Screens.Home;

namespace Veritas.UI.Web.Controllers
{
    public class HomeController : ControllerBase
    {

        public ActionResult About()
        {
            AboutScreen screen = new AboutScreen();
            ViewData.Model = screen;
            return View();
        }
        
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult Contact()
        {
            ContactScreen screen = new ContactScreen();
            ViewData.Model = screen;
        return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Contact(ContactScreen screen)
        {
            //ContactScreen screen = new ContactScreen();
            //TryUpdateModel(screen);
            //screen.SendToUsername = col["AuthorSelectList"];
            screen.SendToUsername = Request.Form["AuthorSelectList"];

            if (screen.IsValid)
            {
                screen.ProcessContactRequest();
                screen.Message = "Your message has been sent.  Thank you.";
                ModelState.Clear();
            }
            else
            {
                //Add get validation rules to contact screen object
                //set validation errors on modelstate .addmodel error
                //Add our validation errors
                foreach (var item in screen.GetValidationErrors())
                {
                    ModelState.AddModelError(item.Key, item.Value);
                }
            }

            ViewData.Model = screen;
            return View();
        }

        public ActionResult Index()
        {
            IndexScreen screen = new IndexScreen();
            ViewData.Model = screen;
            return View();
        }

        public ActionResult Upload()
        {
            return View();
        }

        public ActionResult ViewContent()
        {
            return View();
        }
    }
}
