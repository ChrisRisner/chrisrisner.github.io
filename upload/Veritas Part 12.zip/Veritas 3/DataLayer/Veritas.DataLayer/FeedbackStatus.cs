﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Veritas.DataLayer
{
    public enum FeedbackStatus
    {
        PendingApproval = 0,
        Approved = 1,
        Denied = 2
    }
}
