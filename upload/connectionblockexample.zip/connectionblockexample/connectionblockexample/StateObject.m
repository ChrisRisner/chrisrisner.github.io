//
//  StateObject.m
//  connectionblockexample
//
//  Created by Chris Risner on 6/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "StateObject.h"

@implementation StateObject
    
    @synthesize receivedData;
    @synthesize callbackBlock;

@end
