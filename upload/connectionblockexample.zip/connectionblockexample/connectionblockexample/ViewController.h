//
//  ViewController.h
//  connectionblockexample
//
//  Created by Chris Risner on 6/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceCaller.h"

@interface ViewController : UIViewController {
    @private
    ServiceCaller *serviceCaller;
}

@property (weak, nonatomic) IBOutlet UILabel *lblRequestOne;
@property (weak, nonatomic) IBOutlet UILabel *lblRequestTwo;


- (IBAction)doRequestOne:(id)sender;
- (IBAction)doRequestTwo:(id)sender;




@end
