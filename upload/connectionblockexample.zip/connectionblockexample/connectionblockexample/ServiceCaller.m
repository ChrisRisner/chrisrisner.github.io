//
//  ServiceCaller.m
//  connectionblockexample
//
//  Created by Chris Risner on 6/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ServiceCaller.h"
#import "StateObject.h"

@implementation ServiceCaller

-(ServiceCaller*) init {
    callbacks = [[NSMutableDictionary alloc] init];
    return self;
}

-(void) postToUrl:(NSString *)url withBody:(NSData *)body 
     withCallback: (void (^)(NSString *))callback {
    NSMutableURLRequest* request = [NSMutableURLRequest 
                                    requestWithURL: [NSURL URLWithString:url]];
    [request setHTTPMethod:@"POST"];    
    NSError *error;
    // should check for and handle errors here
    [request setHTTPBody:body];
    NSURLConnection *conn = [[NSURLConnection alloc] 
                             initWithRequest: request delegate:self];
    StateObject* connectionState = [[StateObject alloc] init];
    connectionState.receivedData = [[NSMutableData alloc] init];
    [connectionState.receivedData setLength:0];
    connectionState.callbackBlock = callback;
    [callbacks setValue:connectionState forKey:[NSString stringWithFormat:@"%i", conn.hash]];
}

#pragma NSUrlConnectionDelegate Methods

-(void)connection:(NSConnection*)conn didReceiveResponse:
(NSURLResponse *)response 
{
}

- (void)connection:(NSURLConnection *)connection didReceiveData:
(NSData *)data
{
    StateObject* connectionState = [callbacks objectForKey:[NSString stringWithFormat:@"%i", connection.hash]];
    [connectionState.receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:
(NSError *)error
{    
    //Naive error handling - log it!
    NSLog(@"Connection failed! Error - %@ %@",
          [error localizedDescription],
          [[error userInfo] objectForKey:
           NSURLErrorFailingURLStringErrorKey]);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{   
    NSString* connectionHash = [NSString stringWithFormat:@"%i", connection.hash];    
    StateObject* connectionState = [callbacks objectForKey:connectionHash];    
    NSString *txt = [[NSString alloc] initWithData:connectionState.receivedData
                                          encoding: NSASCIIStringEncoding];    
    connectionState.callbackBlock(txt);
    [callbacks removeObjectForKey:connectionHash];
}

@end