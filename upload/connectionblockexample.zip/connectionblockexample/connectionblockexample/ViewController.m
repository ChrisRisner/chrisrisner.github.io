//
//  ViewController.m
//  connectionblockexample
//
//  Created by Chris Risner on 6/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "ServiceCaller.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblRequestOne;
@synthesize lblRequestTwo;

- (void)viewDidLoad
{
    [super viewDidLoad];

    serviceCaller = [[ServiceCaller alloc] init];
}

- (void)viewDidUnload
{
    [self setLblRequestOne:nil];
    [self setLblRequestTwo:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)doRequestOne:(id)sender {

    [serviceCaller postToUrl:@"http://chrisrisner.com" 
                  withBody:nil withCallback:^(NSString *response) {
                      lblRequestOne.text = response;
                  }];
}

- (IBAction)doRequestTwo:(id)sender {

//    [caller postToUrl:@"http://phptest1.antdf0.antares-test.windows-int.net/api-getall" 
    [serviceCaller postToUrl:@"http://windowsazure.com"
             withBody:nil withCallback:^(NSString *response) {
                 lblRequestTwo.text = response;
             }];
}
@end
