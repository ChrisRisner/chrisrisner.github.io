//
//  ViewController.h
//  DemoWAT
//
//  Created by Stéphane Sibué on 16/07/12.
//  Copyright (c) 2012 SOFTELITE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
