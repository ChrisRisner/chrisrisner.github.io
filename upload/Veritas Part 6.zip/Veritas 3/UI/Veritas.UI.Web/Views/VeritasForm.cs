﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Veritas.DataLayer;
using System.Web.Mvc;

namespace Veritas.UI.Web.Views
{
    public class VeritasForm
    {
        private VeritasRepository repo = VeritasRepository.GetInstance();
        internal const string CACHE_KEY = "_VeritasForm_Cache_Key";
        internal HtmlHelper Helper { get; set; }

        /// <summary>
        /// Our static accessor so we can easily access this from the views.
        /// </summary>
        /// <param name="helper"></param>
        /// <returns></returns>
        public static VeritasForm GetInstance(HtmlHelper helper)
        {
            if (helper.ViewContext.HttpContext.Items.Contains(CACHE_KEY))
                return (VeritasForm)helper.ViewContext.HttpContext.Items[CACHE_KEY];
            VeritasForm form = new VeritasForm(helper);
            helper.ViewContext.HttpContext.Items.Add(CACHE_KEY, form);
            return form;
        }
       
        private VeritasForm(HtmlHelper helper)
        {
            Helper = helper;
        }
    }
}
