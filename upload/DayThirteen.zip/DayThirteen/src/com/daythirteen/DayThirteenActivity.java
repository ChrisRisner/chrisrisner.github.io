package com.daythirteen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DayThirteenActivity extends BaseActivity {
	private TextView lblTextViewOne;
	private EditText editText1;

	public static String MyStaticString;
	private OrientationEventListener MyOrientationEventListener;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Log.i("DayElevenActivity", "onCreate Start");
		//setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		//setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);

		Display display = ((WindowManager) this
				.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		if (display.getOrientation() == Configuration.ORIENTATION_UNDEFINED) {
			if (display.getWidth() == display.getHeight())
				lblTextViewOne.setText("Square");
			else if (display.getHeight() > display.getWidth())
				lblTextViewOne.setText("Portrait");
			else
				lblTextViewOne.setText("Landscape");
		} else if (display.getOrientation() == Configuration.ORIENTATION_PORTRAIT) {
			lblTextViewOne.setText("Not Portrait, Landscape!");
		}

		switch (display.getRotation()) {
		case Surface.ROTATION_0:
			lblTextViewOne.setText("Rotation 0");
			break;
		case Surface.ROTATION_180:
			lblTextViewOne.setText("Rotation 180");
			break;
		case Surface.ROTATION_270:
			lblTextViewOne.setText("Rotation 270");
			break;
		case Surface.ROTATION_90:
			lblTextViewOne.setText("Rotation 90");
			break;
		}

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);

		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());
			}
		});

		Log.i("DayElevenActivity", "onCreate End");

		MyOrientationEventListener = new OrientationEventListener(this,
				SensorManager.SENSOR_DELAY_NORMAL) {
			@Override
			public void onOrientationChanged(int arg0) {
				lblTextViewOne.setText("Orientation: " + String.valueOf(arg0));
			}
		};

		if (MyOrientationEventListener.canDetectOrientation()) {
			MyOrientationEventListener.enable();
		} else {
			lblTextViewOne.setText("Can't DetectOrientation");
			finish();
		}
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		Log.i("DayElevenActivity", "onConfigurationChanged");
		// Checks the orientation of the screen
		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
			lblTextViewOne.setText("onConfigChanged - Landscape");
		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
			lblTextViewOne.setText("onConfigChanged - Portrait");
		}
	}

}