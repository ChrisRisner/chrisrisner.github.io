xcodebuild -target watoolkitios-lib-test -sdk iphonesimulator4.3 -configuration Debug build | grep Exec 
