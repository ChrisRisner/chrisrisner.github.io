package com.msdpe.shortifierdemo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class UrlDetailsActivity extends Activity {
	
	private EditText mTxtUrlSlug;
	private EditText mTxtFullUrl;
	private EditText mTxtShortyUrl;
	private Button mBtnGoToUrl;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_url_details);
		
		// Get controls we'll need regardless of whether we're adding or viewing
		mTxtUrlSlug = (EditText) findViewById(R.id.txtUrlSlug);
		mTxtFullUrl = (EditText) findViewById(R.id.txtFullUrl);
		mTxtShortyUrl = (EditText) findViewById(R.id.txtShortyUrl);
		mBtnGoToUrl = (Button) findViewById(R.id.btnGoToUrl);
		
		//Get extra data from intent
		Intent intent = getIntent();
		final String urlSlug = intent.getStringExtra("UrlSlug");
		final String fullUrl = intent.getStringExtra("FullUrl");
		
		//Set our text fields and disable them
		mTxtUrlSlug.setText(urlSlug);
		mTxtUrlSlug.setFocusable(false);
		mTxtFullUrl.setText(fullUrl);
		mTxtFullUrl.setFocusable(false);
		mTxtShortyUrl.setText("http://urlshortener.azurewebsites.net/" + urlSlug);
		mTxtShortyUrl.setFocusable(false);
		
		mBtnGoToUrl.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//Fire intent to view URL in web browser
				Intent webIntent = new Intent(Intent.ACTION_VIEW);
				webIntent.setData(Uri.parse
						("http://urlshortener.azurewebsites.net/" + urlSlug));
				startActivity(webIntent);
			}
		});
	}
}
