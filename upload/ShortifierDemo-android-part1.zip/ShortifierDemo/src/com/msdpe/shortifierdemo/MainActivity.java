package com.msdpe.shortifierdemo;

import java.util.HashMap;
import java.util.TreeSet;

import com.msdpe.shortifierdemo.services.ServiceResultReceiver;
import com.msdpe.shortifierdemo.services.UrlFetchService;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.support.v4.app.NavUtils;

public class MainActivity extends ListActivity implements ServiceResultReceiver.Receiver {

	private ServiceResultReceiver mReceiver;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);        
        //Create a result receiver to handle service result call backs
		mReceiver = new ServiceResultReceiver(new Handler());
		mReceiver.setReceiver(this);		
        final Intent serviceIntent = new Intent(Intent.ACTION_SYNC, null, 
                getApplicationContext(), UrlFetchService.class);
        // put the specifics for the submission service commands
        serviceIntent.putExtra(UrlFetchService.RECEIVER_KEY, mReceiver);
        serviceIntent.putExtra(UrlFetchService.COMMAND_KEY, UrlFetchService.PERFORM_SERVICE_ACTIVITY);
        //Start the service
        startService(serviceIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    public void onReceiveResult(int resultCode, Bundle resultBundle) {
		switch (resultCode) {
	    case UrlFetchService.STATUS_RUNNING:
	        // Don't do anything, the service is running
	        break;
	    case UrlFetchService.STATUS_SUCCESS:
	        boolean wasSuccess = resultBundle
	                .getBoolean(UrlFetchService.SERVICE_WAS_SUCCESS_KEY);
	        if (wasSuccess) {
	        	//Success, update the ListView
	        	HashMap<String, String> urlMap = (HashMap<String, String>) 
	        			resultBundle.getSerializable("urlMap");
	            showUrlsInListView(urlMap);
	        } else {
	            // Failure, show error message
	            Toast.makeText(getApplicationContext(),
	                    "There was an error fetching the URL data.  Please try again later."
	            		, Toast.LENGTH_LONG).show();
	        }
	        break;
	    case UrlFetchService.STATUS_FINISHED:
	        break;
	    case UrlFetchService.STATUS_ERROR:
	    	//Error returned from service, show and error message
	        Toast.makeText(getApplicationContext(), "There was an error fetching the URL data."
	        		+"Please try again later.",
	                Toast.LENGTH_LONG).show();
	        break;
	    }
	}

	private void showUrlsInListView(HashMap<String, String> urlMap) {				
		TreeSet<String> treeSetKeys = new TreeSet<String>(urlMap.keySet());
		String[] keys = (String[]) treeSetKeys.toArray(new String[treeSetKeys.size()]);
		ArrayAdapter adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, keys);
		setListAdapter(adapter);
	}

    
}
