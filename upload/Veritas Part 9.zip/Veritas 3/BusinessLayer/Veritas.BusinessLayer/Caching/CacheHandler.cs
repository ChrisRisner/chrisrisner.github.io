﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Veritas.DataLayer.Models;
using System.Web;
using Veritas.DataLayer;

namespace Veritas.BusinessLayer.Caching
{
    public static class CacheHandler
    {
        public const string BlogConfigCacheKey = "--BlogConfigCacheKey--";

        public static BlogConfig GetBlogConfig()
        {
            if (HttpContext.Current == null || HttpContext.Current.Cache == null)
            {
                var repo = VeritasRepository.GetInstance();
                return repo.GetAllBlogConfigs().FirstOrDefault();
            }
            if (HttpContext.Current.Cache[BlogConfigCacheKey] == null)
            {
                var repo = VeritasRepository.GetInstance();
                var host = HttpContext.Current.Request.Url.Host;
                var config = repo.GetBlogConfigByHostname(host);
                config.LoadConfigFromXml();
                HttpContext.Current.Cache[BlogConfigCacheKey] = config;
                return config;
            }
            return (HttpContext.Current.Cache[BlogConfigCacheKey] as BlogConfig);
        }

        public static int BlogConfigId
        {
            get { return CacheHandler.GetBlogConfig().BlogConfigId; }
        }
    }
}
