﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Security.Cryptography;
using System.Text;

namespace QuickGravatarExample.UI.Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public string GetGravatarPath(string value)
        {
            return Gravatar.GetGravatarURL(value);
        }
    }

    public class Gravatar
    {
        public static string GetGravatarURL(string emailAddress)
        {
            string imageUrl = "http://www.gravatar.com/avatar.php?";
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            UTF8Encoding encoder = new UTF8Encoding();
            byte[] hashedBytes = md5.ComputeHash(encoder.GetBytes(emailAddress));

            StringBuilder sb = new StringBuilder(hashedBytes.Length * 2);
            for (int i = 0; i < hashedBytes.Length; i++)
            {
                sb.Append(hashedBytes[i].ToString("X2").ToLower());
            }

            imageUrl += "gravatar_id=" + sb.ToString();
            imageUrl += "&size=40";
            return imageUrl;
        }
    }
}
