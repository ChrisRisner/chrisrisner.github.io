﻿window._emailRegex = /^[a-z0-9]+([-+\.]*[a-z0-9]+)*@[a-z0-9]+([-\.][a-z0-9]+)*$/i;

$(document).ready(function() {
    //Gravatar stuff
    $('input[name=Email]').blur(function() {
        var email = $(this).val();
        if (email.indexOf("@") > 0 && window._emailRegex.test(email)) {
            $.post('/Home/GetGravatarPath', { value: email }, function(gravatarPath) {
                $('img.newgravatar').attr('src', gravatarPath);
            });
        }
    });
});