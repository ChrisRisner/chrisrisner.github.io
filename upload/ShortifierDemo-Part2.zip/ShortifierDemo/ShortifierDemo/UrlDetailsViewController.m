//
//  UrlDetailsViewController.m
//  ShortifierDemo
//
//  Created by Chris Risner on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UrlDetailsViewController.h"

@interface UrlDetailsViewController ()

@end

@implementation UrlDetailsViewController

@synthesize urlSlug;
@synthesize fullUrl;
@synthesize txtUrlSlug;
@synthesize txtFullUrl;
@synthesize txtShortyUrl;
@synthesize btnGoToUrl;
@synthesize lblGoToUrl;
@synthesize lblShortyUrl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.txtUrlSlug.text = urlSlug;
    self.txtFullUrl.text = fullUrl;
    self.txtShortyUrl.text = [@"http://urlshortener.azurewebsites.net/" stringByAppendingFormat:urlSlug];
    self.title = @"URL Details";
}

- (void)viewDidUnload
{
    [self setTxtUrlSlug:nil];
    [self setTxtFullUrl:nil];
    [self setTxtShortyUrl:nil];
    [self setBtnGoToUrl:nil];
    [self setLblGoToUrl:nil];
    [self setLblShortyUrl:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)tapGoToUrl:(id)sender {
    NSURL *url = [ [ NSURL alloc ] initWithString: 
                  [@"http://urlshortener.azurewebsites.net/" stringByAppendingFormat:urlSlug] ];
    [[UIApplication sharedApplication] openURL:url];
}
@end
