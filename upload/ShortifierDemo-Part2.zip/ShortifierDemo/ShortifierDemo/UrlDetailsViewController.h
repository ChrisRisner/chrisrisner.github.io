//
//  UrlDetailsViewController.h
//  ShortifierDemo
//
//  Created by Chris Risner on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UrlDetailsViewController : UIViewController

    @property (nonatomic, weak) NSString *urlSlug;
    @property (nonatomic, weak) NSString *fullUrl;
    @property (weak, nonatomic) IBOutlet UITextField *txtUrlSlug;
    @property (weak, nonatomic) IBOutlet UITextField *txtFullUrl;
    @property (weak, nonatomic) IBOutlet UITextField *txtShortyUrl;
    @property (weak, nonatomic) IBOutlet UIButton *btnGoToUrl;
    @property (weak, nonatomic) IBOutlet UILabel *lblGoToUrl;
    @property (weak, nonatomic) IBOutlet UILabel *lblShortyUrl;
    - (IBAction)tapGoToUrl:(id)sender;

@end
