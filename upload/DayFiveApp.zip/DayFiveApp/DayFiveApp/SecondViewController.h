//
//  SecondViewController.h
//  DayFiveApp
//
//  Created by Chris Risner on 9/26/12.
//  Copyright (c) 2012 31DaysOfiOSt. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
- (IBAction)tappedCloseModal:(id)sender;

@end
