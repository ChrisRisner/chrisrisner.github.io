//
//  ViewController.m
//  Azureintegrationsample
//
//  Created by user on 13/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

#import "WATableFetchRequest.h"
#import "WAConfiguration.h"

#import "AppDelegate.h"
@interface ViewController ()

@end

@implementation ViewController
@synthesize resultContinuation=_resultContinuation;
- (void)viewDidLoad
{
    
    [super viewDidLoad];
   	WAConfiguration *config = [WAConfiguration sharedConfiguration];	
	// Do any additional setup after loading the view, typically from a nib.
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.authenticationCredential = [WAAuthenticationCredential credentialWithAzureServiceAccount:config.accountName 
                                                                                               accessKey:config.accessKey];    
    
    storageClient = [[WACloudStorageClient storageClientWithCredential:appDelegate.authenticationCredential] retain];
	storageClient.delegate = self;
    
    
       
    
}


-(IBAction)azure:(id)sender{
    
    WATableFetchRequest *fetchRequest = [WATableFetchRequest fetchRequestForTable:@"hello"];
    fetchRequest.resultContinuation = self.resultContinuation;
    fetchRequest.topRows = 20;
    [storageClient fetchEntitiesWithRequest:fetchRequest];
    
}

- (void)storageClient:(WACloudStorageClient *)client didFetchEntities:(NSArray *)entities fromTableNamed:(NSString *)tableName withResultContinuation:(WAResultContinuation *)resultContinuation
{

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
