//
//  AzureintegrationsampleTests.m
//  AzureintegrationsampleTests
//
//  Created by user on 13/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AzureintegrationsampleTests.h"

@implementation AzureintegrationsampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AzureintegrationsampleTests");
}

@end
