﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml;

namespace Veritas.DataLayer.Models
{
    public partial class BlogConfig
    {
        public bool AllowComments { get; set; }
        public string BlogAbout { get; set; }        
        public int PostCount { get; set; }

        public void LoadConfigFromXml()
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(this.ConfigXml);            
            if (doc.DocumentElement["AllowComments"] != null)
                this.AllowComments = Convert.ToBoolean(doc.DocumentElement["AllowComments"].InnerText);
            if (doc.DocumentElement["BlogAbout"] != null)
                this.BlogAbout = doc.DocumentElement["BlogAbout"].InnerText;
            if (doc.DocumentElement["PostCount"] != null)
                this.PostCount = Convert.ToInt32(doc.DocumentElement["PostCount"].InnerText);

        }

        public void BuildXmlFromConfig()
        {
            XElement blogConfigXml = 
                new XElement("BlogConfig",
                    new XElement("AllowComments", this.AllowComments),
                    new XElement("BlogAbout", this.BlogAbout),
                    new XElement("PostCount", this.PostCount)
                    );            
            this.ConfigXml = blogConfigXml.ToString().Replace("\r\n  ", "").Replace("\r\n", "");            
        }
    }
}
