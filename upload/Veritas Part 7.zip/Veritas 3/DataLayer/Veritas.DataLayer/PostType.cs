﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Veritas.DataLayer
{
    public enum PostType
    {
        Draft = 0,
        Published = 1
    }
}
