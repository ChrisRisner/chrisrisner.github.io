package com.daytwenty;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class DayTwentyActivity extends ListActivity {
	
	String[] values = new String[] { "Day 1 - Getting set up for development",
			 "Day 2 - Creating Android Virtual Devices",
			 "Day 3 - A Java Refresher",
			 "Day 4 - Our First App",
			 "Day 5 - Adding Multiple Activities and using Intents",
			 "Day 6 - Options Menus and Base Activities",
			 "Day 7 - Sharing Data Between Activities",
			 "Day 8 - The Android Project Structure",
			 "Day 9 - Debugging Your Applications",
			 "Day 10 - The Back Button",
			 "Day 11 - Device Orientation",
			 "Day 12 - Linear Layouts",
			 "Day 13 - Relative Layouts",
			 "Day 14 - Table Layout and Frame Layout",
			 "Day 15 - Toasts",
			 "Day 16 - Notifications",
			 "Day 17 - Animating between Activities",
			 "Day 18 - The WebView",
			 "Day 19 - ScrollViews"};
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
        ListView listView = getListView();
        View headerView = getLayoutInflater().inflate(R.layout.second_layout, null);
        listView.addHeaderView(headerView);        
        
        CustomArrayAdapter listAdapter = new CustomArrayAdapter(this, values);
		setListAdapter(listAdapter);		
    }    	
    
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
    	super.onListItemClick(l, v, position, id);
    	Toast.makeText(this, values[position], Toast.LENGTH_LONG).show();
    }
}