//
//  SecondViewController.h
//  DaySixApp
//
//  Created by Chris Risner on 9/26/12.
//  Copyright (c) 2012 31DaysOfiOSt. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SecondViewController;

@protocol SecondViewControllerDelegate <NSObject>
- (void)doSomethingWithSecondViewController:(SecondViewController *)secondViewController;
@end

@interface SecondViewController : UIViewController
@property (nonatomic, weak) id <SecondViewControllerDelegate> delegate;
- (IBAction)tappedCloseModal:(id)sender;

@end
