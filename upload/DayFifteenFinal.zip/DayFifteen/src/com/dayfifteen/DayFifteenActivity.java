package com.dayfifteen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DayFifteenActivity extends BaseActivity {
	private TextView lblTextViewOne;
	private EditText editText1;
	private Activity activity;

	public static String MyStaticString;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Log.i("DayElevenActivity", "onCreate Start");
		//setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		//setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);		
		
		
		activity = this;
		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());
				Toast.makeText(getApplicationContext(), "This is a toast!", Toast.LENGTH_LONG).show();
				Toast myToast = Toast.makeText(getApplicationContext(), R.string.app_name, Toast.LENGTH_SHORT);
				myToast.setGravity(Gravity.CENTER, 0, 0);
				
				
				LayoutInflater inflater = getLayoutInflater();
				View toastLayout = inflater.inflate(R.layout.toast_layout, 
						(ViewGroup) findViewById(R.id.newToastLayout));
				TextView toastTextView = (TextView) toastLayout.findViewById(R.id.textView1);
				toastTextView.setText("This is also a toast!");
				myToast.setView(toastLayout);
				
				
				myToast.show();				
			}
		});		
		
		Log.i("DayElevenActivity", "onCreate End");
	}

}