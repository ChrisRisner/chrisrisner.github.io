package com.daytwentyseven;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

public class DayTwentySevenService extends IntentService {

	// Status Constants
	public static final int STATUS_RUNNING = 0x1;
	public static final int STATUS_FINISHED = 0x2;
	public static final int STATUS_SUCCESS = 0x3;
	public static final int STATUS_ERROR = 0x4;
	// Command Constants
	public static final int PERFORM_SERVICE_ACTIVITY = 0x5;

	public static final String COMMAND_KEY = "service_command";
	public static final String RECEIVER_KEY = "serivce_receiver";
	public static final String SERVICE_WAS_SUCCESS_KEY = "service_was_success";

	private ResultReceiver receiver;

	public DayTwentySevenService() {
		super("DayTwentySevenService");
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		Log.i("dayTwentySevenService", "onhandleintent");
		Log.e("TESTWARN", "4");
		this.receiver = intent.getParcelableExtra(RECEIVER_KEY);
		int command = intent.getIntExtra(COMMAND_KEY, PERFORM_SERVICE_ACTIVITY);
		Log.e("TESTWARN", "5");
		this.receiver.send(STATUS_RUNNING, Bundle.EMPTY);
		switch (command) {
		case PERFORM_SERVICE_ACTIVITY:
			Log.e("TESTWARN", "6");
			doServiceStuff(intent);
			break;
		default:
			Log.e("TESTWARN", "7");
			receiver.send(STATUS_FINISHED, Bundle.EMPTY);
		}
		this.stopSelf();
	}

	private void doServiceStuff(Intent intent) {
		for (int i = 0; i < 100000; i++) {
			String s = "This " + "is " + "a " + "test:" + i ;
			Log.i("Daytwentysevenservice", s);
		}
		
		if (false) { // error
			receiver.send(STATUS_ERROR, Bundle.EMPTY);
			this.stopSelf();
			receiver.send(STATUS_FINISHED, Bundle.EMPTY);
		} else {
			Bundle b = new Bundle();
			b.putBoolean(SERVICE_WAS_SUCCESS_KEY, true);
			receiver.send(STATUS_SUCCESS, b);
			this.stopSelf();
			receiver.send(STATUS_FINISHED, Bundle.EMPTY);
		}
	}
}
