package com.daytwentyseven;

import java.util.List;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DayTwentySevenActivity extends Activity implements
		ServiceResultReceiver.Receiver {
	private TextView lblTextViewOne;
	private EditText editText1;
	private ServiceResultReceiver receiver;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Set our receiver
		receiver = new ServiceResultReceiver(new Handler());
		receiver.setReceiver(this);
		
		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);//

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);

		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());
			}
		});

		Button button2 = (Button) findViewById(R.id.button2);
		button2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				final Intent serviceIntent = new Intent(Intent.ACTION_SYNC, null, 
						getApplicationContext(), DayTwentySevenService.class);
				// put the specifics for the submission service commands
				serviceIntent.putExtra(DayTwentySevenService.RECEIVER_KEY, receiver);
				serviceIntent.putExtra(DayTwentySevenService.COMMAND_KEY, DayTwentySevenService.PERFORM_SERVICE_ACTIVITY);
				//Start the service
				startService(serviceIntent);

			}
		});
	}

	@Override
	public void onReceiveResult(int resultCode, Bundle resultBundle) {
		switch (resultCode) {
		case DayTwentySevenService.STATUS_RUNNING:
			// Don't do anything, the service is running
			break;
		case DayTwentySevenService.STATUS_SUCCESS:
			boolean wasSuccess = resultBundle
					.getBoolean(DayTwentySevenService.SERVICE_WAS_SUCCESS_KEY);
			if (wasSuccess) {
				Toast.makeText(getApplicationContext(),
						"The service was a success", Toast.LENGTH_LONG).show();
			} else {
				// Show not success message
				Toast.makeText(getApplicationContext(),
						"The service was a failure", Toast.LENGTH_LONG).show();
			}
			break;
		case DayTwentySevenService.STATUS_FINISHED:
			Toast.makeText(getApplicationContext(), "The service was finished",
					Toast.LENGTH_LONG).show();
			break;
		case DayTwentySevenService.STATUS_ERROR:
			Toast.makeText(getApplicationContext(), "The service had an error",
					Toast.LENGTH_LONG).show();
			break;
		}
	}

}