﻿using Veritas.DataLayer;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Veritas.Tests
{
    
    
    /// <summary>
    ///This is a test class for VeritasRepositoryTest and is intended
    ///to contain all VeritasRepositoryTest Unit Tests
    ///</summary>
    [TestClass()]
    public class VeritasRepositoryTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for VeritasRepository Constructor
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Veritas.DataLayer.dll")]
        public void VeritasRepositoryConstructorTest()
        {
            VeritasRepository_Accessor target = new VeritasRepository_Accessor();
            Assert.IsNotNull(target);
            //Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for ForceNewInstance
        ///</summary>
        [TestMethod()]
        public void ForceNewInstanceTest()
        {
            VeritasRepository actual;
            actual = VeritasRepository.ForceNewInstance();
            Assert.IsNotNull(actual);
            
        }

        /// <summary>
        ///A test for GetInstance
        ///</summary>
        [TestMethod()]
        public void GetInstanceTest()
        {            
            VeritasRepository actual;
            actual = VeritasRepository.GetInstance();
            Assert.IsNotNull(actual);
        }

        /// <summary>
        ///A test for RollbackTransaction
        ///</summary>
        [TestMethod()]
        public void RollbackTransactionTest()
        {
            VeritasRepository_Accessor target = new VeritasRepository_Accessor(); // TODO: Initialize to an appropriate value
            target.RollbackTransaction();
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for StartTransaction
        ///</summary>
        [TestMethod()]
        public void StartTransactionTest()
        {
            VeritasRepository_Accessor target = new VeritasRepository_Accessor(); // TODO: Initialize to an appropriate value
            target.StartTransaction();
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }
    }
}
