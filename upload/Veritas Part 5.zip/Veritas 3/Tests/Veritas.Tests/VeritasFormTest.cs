﻿using Veritas.UI.Web.Views;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;
using System.Web.Mvc;

namespace Veritas.Tests
{
    
    
    /// <summary>
    ///This is a test class for VeritasFormTest and is intended
    ///to contain all VeritasFormTest Unit Tests
    ///</summary>
    [TestClass()]
    public class VeritasFormTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for VeritasForm Constructor
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]        
        public void VeritasFormConstructorTest()
        {
            Assert.IsFalse(true, "Need to mock HtmlHelper");
            HtmlHelper helper = null; // TODO: Initialize to an appropriate value
            VeritasForm_Accessor target = new VeritasForm_Accessor(helper);
            Assert.Inconclusive("TODO: Implement code to verify target");
        }

        /// <summary>
        ///A test for GetInstance
        ///</summary>

        [TestMethod()]
        public void GetInstanceTest()
        {
            Assert.IsFalse(true, "Need to mock HtmlHelper");
            //HtmlHelper helper = new HtmlHelper(
            //VeritasForm actual;
            //actual = VeritasForm.GetInstance(helper);

            //Assert.IsNotNull(actual);
        }

        /// <summary>
        ///A test for Helper
        ///</summary>
        // TODO: Ensure that the UrlToTest attribute specifies a URL to an ASP.NET page (for example,
        // http://.../Default.aspx). This is necessary for the unit test to be executed on the web server,
        // whether you are testing a page, web service, or a WCF service.
        [TestMethod()]
        public void HelperTest()
        {
            Assert.IsFalse(true, "Need to mock HtmlHelper");
            //PrivateObject param0 = null; // TODO: Initialize to an appropriate value
            //VeritasForm_Accessor target = new VeritasForm_Accessor(param0); // TODO: Initialize to an appropriate value
            //HtmlHelper expected = null; // TODO: Initialize to an appropriate value
            //HtmlHelper actual;
            //target.Helper = expected;
            //actual = target.Helper;
            //Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
