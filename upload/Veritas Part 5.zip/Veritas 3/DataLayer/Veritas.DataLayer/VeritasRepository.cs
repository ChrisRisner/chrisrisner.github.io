﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Veritas.DataLayer
{
    public class VeritasRepository
    {
        internal const string CACHE_KEY = "_VeritasRepository_Cache_Key";

        private VeritasRepository() { }

        /// <summary>
        /// Static method to get an instance of our Veritas Repostiory.  
        /// Checks to see if we have a context in case we're using 
        /// this in a unit test.
        /// </summary>
        /// <returns></returns>
        public static VeritasRepository GetInstance()
        {
            if (HttpContext.Current == null)
                return new VeritasRepository();

            if (HttpContext.Current.Items.Contains(CACHE_KEY))
                return (VeritasRepository)HttpContext.Current.Items[CACHE_KEY];

            VeritasRepository repo = new VeritasRepository();
            HttpContext.Current.Items[CACHE_KEY] = repo;
            return repo;
        }

        /// <summary>
        /// Forces us to get a new instace for testing purposes
        /// </summary>
        /// <returns></returns>
        public static VeritasRepository ForceNewInstance()
        {
            VeritasRepository repo = new VeritasRepository();
            if (HttpContext.Current != null)
            {
                if (HttpContext.Current.Items.Contains(CACHE_KEY))
                    HttpContext.Current.Items[CACHE_KEY] = repo;
                else
                    HttpContext.Current.Items.Add(CACHE_KEY, repo);
            }
            return repo;
        }

        /// <summary>
        /// Will create a new transation.  Not implemented now but will be later.
        /// </summary>
        public void StartTransaction()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Rolls back a transation.  Not implemented now but will be later.
        /// </summary>
        public void RollbackTransaction()
        {
            throw new NotImplementedException();
        }
    }
}
