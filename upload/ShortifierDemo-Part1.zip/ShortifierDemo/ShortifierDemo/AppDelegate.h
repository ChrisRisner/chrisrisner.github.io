//
//  AppDelegate.h
//  ShortifierDemo
//
//  Created by Chris Risner on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
//We're using a MutableDictionary so we can add a URL Slug to it 
//without having to pull all new data
@property (strong, nonatomic) NSMutableDictionary *urls;

@end
