//
//  ViewController.m
//  ShortifierDemo
//
//  Created by Chris Risner on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tableView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    //Hit the server for URL data
    dispatch_queue_t backgroundQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(backgroundQueue, ^{
        NSData* data = [NSData dataWithContentsOfURL: 
                        [NSURL URLWithString: @"http://urlshortener.azurewebsites.net/api-getall"]];
        [self performSelectorOnMainThread:@selector(fetchedData:) 
                               withObject:data waitUntilDone:YES];
    });
}

- (void)viewDidUnload
{
    [self setTableView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)fetchedData:(NSData *)responseData {
    //parse out the json data
    NSError* error;
    NSDictionary* json = [NSJSONSerialization 
              JSONObjectWithData:responseData
              
              options:kNilOptions 
              error:&error];
    
    NSString* status =[json objectForKey:@"Status"];
    NSLog(@"status: %@", status);
    _success = [status isEqualToString:@"SUCCESS"];
    
    //If we successfuly pulled the URLs, show them
    if (_success) {
        NSDictionary* urls = [json objectForKey:@"Urls"];
        NSLog(@"urls: %@", urls);
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        appDelegate.urls = [urls mutableCopy];
        
        [self.tableView reloadData];
    } else {
        //Otherwise, show an error
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" 
                    message:@"There was an error loading the URL data.  Please try again later." 
                   delegate:self 
          cancelButtonTitle:@"OK"
          otherButtonTitles:nil];
        [alert show];
    }
}    



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{    
    // Return the number of rows in the section.
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    return [appDelegate.urls count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    NSLog( @"Indexpath %i", [ indexPath row ] );
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSArray *keys = [[appDelegate.urls allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
    NSString *key = [keys objectAtIndex:[indexPath row]];
    cell.textLabel.text = key;
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
    
    
}



@end
