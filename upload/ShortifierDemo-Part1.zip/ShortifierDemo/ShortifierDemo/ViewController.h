//
//  ViewController.h
//  ShortifierDemo
//
//  Created by Chris Risner on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
@private
    BOOL _success;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end



