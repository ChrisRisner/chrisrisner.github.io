package com.daytwentysix;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DayTwentySixActivity extends Activity {
	private TextView lblTextViewOne;
	private EditText editText1;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
        lblTextViewOne.setText(R.string.test_one);//
        
        editText1 = (EditText) findViewById(R.id.editText1);
        editText1.setText(R.string.test_one);
        
        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());				
			}
		});
        
        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {
				//Start ActivityTwo
				/*
				Intent intent = new Intent(getApplicationContext(), ActivityTwo.class);
				intent.putExtra("MyStringValue", editText1.getText().toString());
				startActivity(intent);
				*/
				
				//Make a phone call
				/*
		        //Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:8887676424")); 
				Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:8887676424"));
		        startActivity(callIntent);
		        */
				
				//Share
				/*
				Intent shareIntent = new Intent(Intent.ACTION_SEND);
				shareIntent.setType("text/plain");
				shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, editText1.getText().toString());
				startActivity(Intent.createChooser(shareIntent,"Share with"));
				*/
				
				//Share specifically through email
				/*
				Intent shareIntent = new Intent(Intent.ACTION_SEND);
				shareIntent.setType("message/rfc822");
				shareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "the subject");				
				shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, editText1.getText().toString());
				startActivity(Intent.createChooser(shareIntent,"Email with"));
				*/
				
				//Open a url				 
				/*
				Intent webIntent = new Intent(Intent.ACTION_VIEW);  
				webIntent.setData(Uri.parse("http://www.chrisrisner.com"));  
				startActivity(webIntent);  
				*/
				
				//Open maps with this address
				/*
				Intent myIntent = new Intent(Intent.ACTION_VIEW, 
						Uri.parse("geo:0,0?q=1600+Amphitheatre+Parkway,+Mountain+View,+CA+94043"));
				startActivity(myIntent);
				*/
				
				//Create a calendar event
				/*
				Intent calendarIntent = new Intent(Intent.ACTION_EDIT);
				calendarIntent.setType("vnd.android.cursor.item/event");
				calendarIntent.putExtra("title", "The event title");
				calendarIntent.putExtra("description", "The event description");
				calendarIntent.putExtra("eventLocation", "1600+Amphitheatre+Parkway,+Mountain+View,+CA+94043");
	    		startActivity(calendarIntent);
				*/
	    		
	    		
	    		//Launch the marketplace and search for the app
				/*
	    		Uri marketUri = Uri.parse("market://search?q=com.google.android.apps.plus");
	    		Intent marketIntent = new Intent(Intent.ACTION_VIEW).setData(marketUri);
	    		startActivity(marketIntent);
	    		*/
			}
		});
    }
    
    
    
    
			
}