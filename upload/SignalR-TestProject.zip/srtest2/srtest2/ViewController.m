//
//  ViewController.m
//  srtest2
//
//  Created by Chris Risner on 8/1/12.
//  Copyright (c) 2012 Chris Risner. All rights reserved.
//

#import "ViewController.h"
#import "SignalR.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize txtHitCount;
SRHubProxy *myHub;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    SRHubConnection *connection = [SRHubConnection connectionWithURL:
                                   @"http://msdpe-signalrconnect.azurewebsites.net"];
    myHub = [connection createProxy:@"HitCounter"];
    [myHub on:@"showHitCount" perform:self selector:@selector(notificationReceived:)];
    connection.started = ^{
        [myHub invoke:@"addHit" withArgs:nil];
    };
    [connection start];
}

- (void)notificationReceived:(id)message
{
    //do something with the message
    NSLog(@"%@",message);
    txtHitCount.text = [@"There have been " stringByAppendingFormat:@"%@ views", message];
}

- (void)viewDidUnload
{
    [self setTxtHitCount:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)tapAddHit:(id)sender {
    [myHub invoke:@"addHit" withArgs:nil];
}
@end
