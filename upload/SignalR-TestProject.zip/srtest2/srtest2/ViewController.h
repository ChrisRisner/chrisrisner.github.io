//
//  ViewController.h
//  srtest2
//
//  Created by Chris Risner on 8/1/12.
//  Copyright (c) 2012 Chris Risner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
    - (IBAction)tapAddHit:(id)sender;
    @property (weak, nonatomic) IBOutlet UILabel *txtHitCount;
@end
