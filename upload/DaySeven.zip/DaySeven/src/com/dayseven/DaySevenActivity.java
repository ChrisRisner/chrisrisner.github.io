package com.dayseven;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DaySevenActivity extends BaseActivity {
	private TextView lblTextViewOne;
	private EditText editText1;
	
	public static String MyStaticString;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);//

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);

		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());
			}
		});

		Button button2 = (Button) findViewById(R.id.button2);
		button2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent myIntent = new Intent(getApplicationContext(), ActivityTwo.class);
				myIntent.putExtra("MyString", editText1.getText().toString());
				PassableObject passableObject = new PassableObject();
				passableObject.setMyStringValue(editText1.getText().toString());
				myIntent.putExtra("MyPassableObject", passableObject);
				startActivity(myIntent);
				//Sets the Static String on the DaySevenActvity
				MyStaticString = editText1.getText().toString();
				//Get our Application Instance
				MyApplication myApp = (MyApplication) getApplication();
				//Set the app string on our app instance
				myApp.setMyApplicationString(editText1.getText().toString());
			}
		});
	}

	
}