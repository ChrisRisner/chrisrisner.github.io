package com.dayseven;

import android.os.Parcel;
import android.os.Parcelable;

public class PassableObject implements Parcelable {
	private String myStringValue;

	public PassableObject() {}
	
	public PassableObject(Parcel inParcel) {
		myStringValue = inParcel.readString();
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel outParcel, int flags) {
		outParcel.writeString(myStringValue);
	}

	public String getMyStringValue() {
		return myStringValue;
	}

	public void setMyStringValue(String myStringValue) {
		this.myStringValue = myStringValue;
	}

	public static final Parcelable.Creator<PassableObject> CREATOR 
	= new Parcelable.Creator<PassableObject>() {
		public PassableObject createFromParcel(Parcel in) {
			return new PassableObject(in);
		}

		public PassableObject[] newArray(int size) {
			return new PassableObject[size];
		}
	};
}
