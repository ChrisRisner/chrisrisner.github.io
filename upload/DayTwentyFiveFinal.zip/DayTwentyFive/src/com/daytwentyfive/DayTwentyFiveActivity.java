package com.daytwentyfive;

import java.util.ArrayList;

import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.StructuredName;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.RawContacts;
import android.provider.ContactsContract.RawContacts.Data;
import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DayTwentyFiveActivity extends Activity {
	private TextView lblTextViewOne;
	private EditText editText1;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);//

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);

		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Uri contactsUri = ContactsContract.Contacts.CONTENT_URI;

				// Returns all contacts
				/*
				 * Cursor cursor = managedQuery(contactsUri, null, null, null,
				 * null);
				 */

				// Returns only specific columns from all contacts
				/*
				 * String[] projection = new String[] {
				 * ContactsContract.Contacts.DISPLAY_NAME,
				 * ContactsContract.Contacts.TIMES_CONTACTED,
				 * ContactsContract.Contacts.LAST_TIME_CONTACTED,
				 * ContactsContract.Contacts.STARRED };
				 * 
				 * Cursor cursor = managedQuery(contactsUri, projection, null,
				 * null, null);
				 */

				// Returns all contacts and columns ordered by last time
				// contacted descending
				Cursor cursor = managedQuery(contactsUri, null, null, null,
						ContactsContract.Contacts.LAST_TIME_CONTACTED + " DESC");

				if (cursor != null && cursor.getCount() > 0) {
					StringBuilder sb = new StringBuilder();
					while (cursor.moveToNext()) {
						sb.append("Name-");
						sb.append(cursor.getString(cursor
								.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)));
						sb.append("\n");
					}
					lblTextViewOne.setText(sb.toString());
				} else {
					lblTextViewOne.setText("Couldn't find any contacts");
				}
			}
		});

		Button button2 = (Button) findViewById(R.id.button2);
		button2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				try {
					Uri newContactUri;

					ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
					int rawContactInsertIndex = ops.size();

					 ops.add(ContentProviderOperation
					 .newInsert(RawContacts.CONTENT_URI)
					 .withValue(RawContacts.ACCOUNT_TYPE, null)
					 .withValue(RawContacts.ACCOUNT_NAME, null).build());
					ops.add(ContentProviderOperation
							.newInsert(ContactsContract.Data.CONTENT_URI)
							.withValueBackReference(Data.RAW_CONTACT_ID,
									rawContactInsertIndex)
							.withValue(Data.MIMETYPE,
									StructuredName.CONTENT_ITEM_TYPE)
							.withValue(StructuredName.DISPLAY_NAME,
									"New Contact Name").build());
					ContentProviderResult[] res = getContentResolver()
							.applyBatch(ContactsContract.AUTHORITY, ops);
					newContactUri = res[0].uri;
					Log.i("DayTWentyFiveActivity", "legnth =  " + res.length);
					Log.i("DayTwentyFiveActivity", newContactUri.toString());

					 String newContactId =
					 String.valueOf(ContentUris.parseId(newContactUri));
					 
					 //Updates the record you just inserted
					 ops.clear();
					 ops.add(ContentProviderOperation
							 .newUpdate(RawContacts.CONTENT_URI)
							 .withValue(RawContacts.ACCOUNT_TYPE, null)
							 .withValue(RawContacts.ACCOUNT_NAME, null).build());
					 ops.add(ContentProviderOperation.newUpdate(ContactsContract.Data.CONTENT_URI)
							 .withValue(StructuredName.DISPLAY_NAME, "Updated contact name")
							 .withSelection(Data.RAW_CONTACT_ID + "=?", new String[] {newContactId})
							 .build());
					 res = getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
					 newContactUri = res[0].uri;

												
				} catch (Exception ex) {

				}
			}
		});
	}

}