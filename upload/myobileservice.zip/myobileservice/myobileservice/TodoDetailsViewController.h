//
//  TodoDetailsViewController.h
//  myobileservice
//
//  Created by Chris Risner on 8/29/12.
//  Copyright (c) 2012 MSDPE. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TodoDetailsViewController;

@protocol TodoDetailsViewControllerDelegate <NSObject>
- (void)todoDetailsViewController:(TodoDetailsViewController *)controller didFinishWithTodo:(NSString *)todoId andTodoText:(NSString *)todoText;
@end

@interface TodoDetailsViewController : UIViewController<NSURLConnectionDelegate> {
    @private
    NSNumber* todoId;
    NSMutableData* receivedData;
    NSHTTPURLResponse* httpResponse;
}
@property (weak, nonatomic) IBOutlet UIView *viewCreateTodo;
@property (weak, nonatomic) IBOutlet UIView *viewDetailsTodo;
@property (weak, nonatomic) IBOutlet UITextField *txtTodoText;
@property (weak, nonatomic) IBOutlet UILabel *lblTodoText;
@property (nonatomic, weak) id <TodoDetailsViewControllerDelegate> delegate;
@property (nonatomic, weak) NSString *todoText;
@property BOOL addingNewTodo;
- (IBAction)tapSaveTodo:(id)sender;
- (IBAction)tapMarkTodoComplete:(id)sender;

@end
