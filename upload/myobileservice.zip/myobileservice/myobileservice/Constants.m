//
//  Constants.m
//  myobileservice
//
//  Created by Chris Risner on 8/29/12.
//  Copyright (c) 2012 MSDPE. All rights reserved.
//

#import "Constants.h"

@implementation Constants
    NSString *kGetAllUrl = @"https://yoursubdomain.azure-mobile.net/tables/TodoItem?$filter=(complete%20eq%20false)";
    NSString *kAddUrl = @"https://yoursubdomain.azure-mobile.net/tables/TodoItem";
    NSString *kUpdateUrl = @"https://yoursubdomain.azure-mobile.net/tables/TodoItem/";
    NSString *kMobileServiceAppId = @"yourappid";
@end
