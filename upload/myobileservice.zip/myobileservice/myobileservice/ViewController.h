//
//  ViewController.h
//  myobileservice
//
//  Created by Chris Risner on 8/29/12.
//  Copyright (c) 2012 MSDPE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TodoDetailsViewController.h"

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,
    NSURLConnectionDelegate, TodoDetailsViewControllerDelegate> {
    @private
    NSMutableData* receivedData;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end
