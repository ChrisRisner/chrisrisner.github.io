//
//  TodoDetailsViewController.m
//  myobileservice
//
//  Created by Chris Risner on 8/29/12.
//  Copyright (c) 2012 MSDPE. All rights reserved.
//

#import "TodoDetailsViewController.h"
#import "AppDelegate.h"
#import "Constants.h"

@interface TodoDetailsViewController ()

@end

@implementation TodoDetailsViewController
@synthesize viewCreateTodo;
@synthesize viewDetailsTodo;
@synthesize txtTodoText;
@synthesize lblTodoText;
@synthesize addingNewTodo;
@synthesize todoText;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (addingNewTodo == NO) {
        //Viewing an existing todo
        viewCreateTodo.hidden = YES;
        lblTodoText.text = todoText;
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        for (NSDictionary *item in appDelegate.todos) {
            if ([todoText isEqualToString:[item objectForKey:@"text"]]){
                NSLog(@"Item: %@", item);
                todoId = (NSNumber*) [item objectForKey:@"id"];
                break;
            }
        }
    } else {
        //Adding a new todo
        viewDetailsTodo.hidden = YES;
    }
}

- (void)viewDidUnload
{
    [self setTxtTodoText:nil];
    [self setLblTodoText:nil];
    [self setViewCreateTodo:nil];
    [self setViewDetailsTodo:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)tapSaveTodo:(id)sender {
    NSMutableURLRequest *theRequest=[NSMutableURLRequest
                                     requestWithURL:
                                     [NSURL URLWithString:kAddUrl]
                                     cachePolicy:NSURLRequestUseProtocolCachePolicy
                                     timeoutInterval:60.0];
    [theRequest setHTTPMethod:@"POST"];
    [theRequest addValue:@"application/json" forHTTPHeaderField:@"ACCEPT"];
    [theRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue:kMobileServiceAppId forHTTPHeaderField:@"X-ZUMO-APPLICATION"];
    //build an info object and convert to json
    NSDictionary* jsonDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"false", @"complete",
                                    txtTodoText.text, @"text",
                                    nil];
    //convert JSON object to data
    NSError *error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:jsonDictionary
                           options:NSJSONWritingPrettyPrinted error:&error];
    [theRequest setHTTPBody:jsonData];
    // create the connection with the request and start loading the data
    NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
    if (theConnection) {
        // Create the NSMutableData to hold the received data.
        // receivedData is an instance variable declared elsewhere.
        receivedData = [NSMutableData data];
    } else {
        // We should inform the user that the connection failed.
    }
}

#pragma NSUrlConnectionDelegate Methods

-(void)connection:(NSConnection*)conn didReceiveResponse:(NSURLResponse *)response {
    if (receivedData == NULL) {
        receivedData = [[NSMutableData alloc] init];
    }
    [receivedData setLength:0];
    httpResponse = (NSHTTPURLResponse*)response;
    NSLog(@"Code: %i", [httpResponse statusCode]);
    NSLog(@"didReceiveResponse: responseData length:(%d)", receivedData.length);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    // Append the new data to receivedData.
    // receivedData is an instance variable declared elsewhere.
    [receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error {
    // inform the user
    NSLog(@"Connection failed! Error - %@ %@",
          [error localizedDescription],
          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSLog(@"Succeeded! Received %d bytes of data",[receivedData length]);
    if ([httpResponse statusCode]== 200 || [httpResponse statusCode] == 201) {
        [self.navigationController popViewControllerAnimated:YES];
        [self.delegate todoDetailsViewController:self didFinishWithTodo:nil andTodoText:nil];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failure"
                        message:@"Failed to mark item completed."
                       delegate:self
              cancelButtonTitle:@"OK"
              otherButtonTitles:nil];
        [alert show];
    }
}


- (IBAction)tapMarkTodoComplete:(id)sender {
    NSURL *urlUpdate = [[ NSURL alloc ] initWithString:[kUpdateUrl stringByAppendingFormat:@"%@",todoId] ];
    NSMutableURLRequest *theRequest=[NSMutableURLRequest
                                     requestWithURL:urlUpdate
                                     cachePolicy:NSURLRequestUseProtocolCachePolicy
                                     timeoutInterval:60.0];
    [theRequest setHTTPMethod:@"PATCH"];
    [theRequest addValue:@"application/json" forHTTPHeaderField:@"ACCEPT"];
    [theRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue:kMobileServiceAppId forHTTPHeaderField:@"X-ZUMO-APPLICATION"];
    //build an info object and convert to json
    NSDictionary* jsonDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"true", @"complete",
                                    todoId, @"id",
                                    todoText, @"text",
                                    nil];
    //convert JSON object to data
    NSError *error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:jsonDictionary
                               options:NSJSONWritingPrettyPrinted error:&error];
    [theRequest setHTTPBody:jsonData];
    // create the connection with the request and start loading the data
    NSURLConnection *theConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
    if (theConnection) {
        // Create the NSMutableData to hold the received data.
        // receivedData is an instance variable declared elsewhere.
        receivedData = [NSMutableData data];
    } else {
        // We should inform the user that the connection failed.
    }
}
@end
