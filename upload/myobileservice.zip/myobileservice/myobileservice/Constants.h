//
//  Constants.h
//  myobileservice
//
//  Created by Chris Risner on 8/29/12.
//  Copyright (c) 2012 MSDPE. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constants : NSObject
    extern NSString *kGetAllUrl;
    extern NSString *kAddUrl;
    extern NSString *kUpdateUrl;
    extern NSString *kMobileServiceAppId;
@end
