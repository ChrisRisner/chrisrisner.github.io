﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Veritas.DataLayer;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using Veritas.BusinessLayer;
using System.Web.Routing;

namespace Veritas.UI.Web.Views
{
    public class VeritasForm
    {
        private VeritasRepository repo = VeritasRepository.GetInstance();
        internal const string CACHE_KEY = "_VeritasForm_Cache_Key";
        internal HtmlHelper Hhelper { get; set; }
        internal UrlHelper Uhelper { get; set; }

        /// <summary>
        /// Our static accessor so we can easily access this from the views.
        /// </summary>
        /// <param name="helper"></param>
        /// <returns></returns>
        public static VeritasForm GetInstance(HtmlHelper htmlHelper, UrlHelper urlHelper)
        {
            if (htmlHelper.ViewContext.HttpContext == null)
                return new VeritasForm(htmlHelper, urlHelper);

            if (htmlHelper.ViewContext.HttpContext.Items.Contains(CACHE_KEY))
                return (VeritasForm)htmlHelper.ViewContext.HttpContext.Items[CACHE_KEY];
            VeritasForm form = new VeritasForm(htmlHelper, urlHelper);
            htmlHelper.ViewContext.HttpContext.Items.Add(CACHE_KEY, form);
            return form;
        }
       
        private VeritasForm(HtmlHelper htmlHelper, UrlHelper urlHelper)
        {
            Hhelper = htmlHelper;
            Uhelper = urlHelper;
        }

        public string ActionLink(string linkText, string actionName, string controller)
        {            
            return Hhelper.ActionLink(linkText, actionName, controller, null, new { Title = linkText }).ToString().AutoRemoveAlias();
        }

        public string ActionLink(string linkText, string actionName, object routeValues)
        {
            return Hhelper.ActionLink(linkText, actionName, routeValues, new { Title = linkText }).ToString().AutoRemoveAlias();
        }

        public string ActionLink(string linkText, string actionName)
        {
            return Hhelper.ActionLink(linkText, actionName, null, new { Title = linkText }).ToString().AutoRemoveAlias();
        }

        public string Action(string actionName)
        {
            return Uhelper.Action(actionName).AutoRemoveAlias();           
        }

        public string Action(string actionName, object routeValues)
        {
            return Uhelper.Action(actionName, routeValues).AutoRemoveAlias();
        }

        public string Action(string actionName, string controllerName)
        {
            return Uhelper.Action(actionName, controllerName).AutoRemoveAlias();
        }

        public string Action(string actionName, RouteValueDictionary routeValues)
        {
            return Uhelper.Action(actionName, routeValues);
        }

        public string Action(string actionName, string controllerName, object routeValues)
        {
            return Uhelper.Action(actionName, controllerName, routeValues).AutoRemoveAlias();
        }

        public string Action(string actionName, string controllerName, RouteValueDictionary routeValues)
        {
            return Uhelper.Action(actionName, controllerName, routeValues).AutoRemoveAlias();
        }

        public string Action(string actionName, string controllerName, object routeValues, string protocol)
        {
            return Uhelper.Action(actionName, controllerName, routeValues, protocol).AutoRemoveAlias();
        }

        public string Action(string actionName, string controllerName, RouteValueDictionary routeValues, string protocol, string hostName)
        {
            return Uhelper.Action(actionName, controllerName, routeValues, protocol, hostName).AutoRemoveAlias();
        }
 


        public string Content(string contentPath)
        {
            return Uhelper.Content(contentPath);
        }

        public string GetUserNameById(int? userId)
        {
            if (userId.HasValue && userId.Value > 0)
                return (repo.GetBlogUserByUserId(userId.Value).Username);
            return "No username";
        }
    }
}
