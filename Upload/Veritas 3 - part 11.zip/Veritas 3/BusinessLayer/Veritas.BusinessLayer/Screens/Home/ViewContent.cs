﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Veritas.BusinessLayer.Screens.Home
{
    public class ViewContent : ScreenBase
    {
        protected override void LoadScreen()
        {
            throw new NotImplementedException();
        }

        public override bool IsValid
        {
            get { throw new NotImplementedException(); }
        }
    }
}
