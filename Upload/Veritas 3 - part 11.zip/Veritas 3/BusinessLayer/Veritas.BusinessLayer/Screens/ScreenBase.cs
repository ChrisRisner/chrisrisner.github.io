﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Veritas.DataLayer;
using Veritas.DataLayer.Models;
using Veritas.BusinessLayer.Caching;

namespace Veritas.BusinessLayer.Screens
{
    public abstract class ScreenBase
    {
        protected VeritasRepository repo = VeritasRepository.GetInstance();
        

        public ScreenBase()  {  }

        public BlogConfig blogConfig
        {
            get { return CacheHandler.GetBlogConfig(); }
        }

        /// <summary>
        /// Determines if the entites associated with the view 
        /// are valid or not.
        /// </summary>
        public abstract bool IsValid { get; }

        /// <summary>
        /// Loads up whatever entities this screen may need.
        /// </summary>
        protected abstract void LoadScreen();        
    }
}
