package com.daytwentynine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ActivityTwo extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.second_layout);
		
		TextView textView1 = (TextView) findViewById(R.id.textView1);
		Intent intent = getIntent();
		
		if (intent.getStringExtra("MyStringValue") != null)
			textView1.setText(intent.getStringExtra("MyStringValue"));
		else if (intent.getAction().equals(Intent.ACTION_SEND)) { 		
			textView1.setText("Created by sharing! And text is " + 
					intent.getStringExtra(android.content.Intent.EXTRA_TEXT));
		}
		
	}
}
