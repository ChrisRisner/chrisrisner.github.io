package com.daytwentynine;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DayTwentyNineActivity extends Activity {
	private TextView lblTextViewOne;
	private EditText editText1;
	private Uri fileUri;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
		lblTextViewOne.setText(R.string.test_one);//

		editText1 = (EditText) findViewById(R.id.editText1);
		editText1.setText(R.string.test_one);

		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());
			}
		});

		Button button2 = (Button) findViewById(R.id.button2);
		button2.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// Start ActivityTwo
				/*
				 * Intent intent = new Intent(getApplicationContext(),
				 * ActivityTwo.class); intent.putExtra("MyStringValue",
				 * editText1.getText().toString()); startActivity(intent);
				 */
				try {
					PackageManager packageManager = getPackageManager();
					boolean doesHaveCamera = packageManager
							.hasSystemFeature(PackageManager.FEATURE_CAMERA);

					if (doesHaveCamera) {
						// start the image capture Intent
						Intent intent = new Intent(
								MediaStore.ACTION_IMAGE_CAPTURE);
						// Get our fileURI
						fileUri = getOutputMediaFile();
						intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
						startActivityForResult(intent, 100);
					}
				} catch (Exception ex) {
					Toast.makeText(getApplicationContext(),
							"There was an error with the camera.",
							Toast.LENGTH_LONG).show();
				}
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode,
			Intent intent) {
		if (requestCode == 100) {
			if (resultCode == RESULT_OK) {
				if (intent == null) {
					// The picture was taken but not returned
					Toast.makeText(
							getApplicationContext(),
							"The picture was taken and is located here: "
									+ fileUri.toString(), Toast.LENGTH_LONG)
							.show();
				} else {
					// The picture was returned
					Bundle extras = intent.getExtras();
					ImageView imageView1 = (ImageView) findViewById(R.id.imageView1);
					imageView1.setImageBitmap((Bitmap) extras.get("data"));
				}
			}
		}
	}

	private Uri getOutputMediaFile() throws IOException {
		File mediaStorageDir = new File(
				Environment
						.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
				"DayTwentyNine");
		// Create a media file name
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
		File mediaFile;
		mediaFile = new File(mediaStorageDir.getPath() + File.separator
				+ "IMG_" + timeStamp + ".jpg");

		if (mediaFile.exists() == false) {
			mediaFile.getParentFile().mkdirs();
			mediaFile.createNewFile();
		}
		return Uri.fromFile(mediaFile);
	}

}