package com.dayfourteen;

import android.app.Application;
import android.content.res.Configuration;

public class MyApplication extends Application {
	private String myApplicationString;

	public String getMyApplicationString() {
		return myApplicationString;
	}
	
	public void setMyApplicationString(String myApplicationString) {
		this.myApplicationString = myApplicationString;
	}		
}
