package com.daytwelve;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.TextView;

public class ActivityTwo extends BaseActivity {	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.second_layout);	
		
		TextView textView1 = (TextView) findViewById(R.id.textView1);
		if (!DayTwelveActivity.MyStaticString.equals(""))
			textView1.setText(DayTwelveActivity.MyStaticString);
		else
			textView1.setText("MyStaticString is empty");
		
		//Get our Application Instance
		MyApplication myApp = (MyApplication) getApplication();
		//Set the textview's text using the app's string
		textView1.setText(myApp.getMyApplicationString());
		
		Intent myIntent = getIntent();
		textView1.setText(myIntent.getStringExtra("MyString"));
		
		PassableObject passableObject = (PassableObject)
				myIntent.getParcelableExtra("MyPassableObject");
		textView1.setText(passableObject.getMyStringValue());			
	}
	
	@Override
	public void onBackPressed() {
		super.onBackPressed();
	    
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)  {
	    if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
	    	//Do something on back press
	    }

	    return super.onKeyDown(keyCode, event);
	}
}
