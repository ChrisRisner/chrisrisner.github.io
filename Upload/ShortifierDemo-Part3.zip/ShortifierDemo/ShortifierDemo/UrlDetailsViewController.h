//
//  UrlDetailsViewController.h
//  ShortifierDemo
//
//  Created by Chris Risner on 7/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UrlDetailsViewController;

@protocol UrlDetailsViewControllerDelegate <NSObject>
- (void)urlDetailsViewController:(UrlDetailsViewController *)controller didAddUrlWithSlug:(NSString *)urlSlug andFullUrl:(NSString *)fullUrl;
@end

@interface UrlDetailsViewController : UIViewController <UITextFieldDelegate>
    @property (nonatomic, weak) id <UrlDetailsViewControllerDelegate> delegate;
    @property (nonatomic, weak) NSString *urlSlug;
    @property (nonatomic, weak) NSString *fullUrl;
    @property (weak, nonatomic) IBOutlet UITextField *BmakUItxtUrlSlug;
    @property (weak, nonatomic) IBOutlet UITextField *txtFullUrl;
    @property (weak, nonatomic) IBOutlet UITextField *txtShortyUrl;
    @property (weak, nonatomic) IBOutlet UITextField *txtUrlSlug;
    @property (weak, nonatomic) IBOutlet UIButton *btnGoToUrl;
    @property (weak, nonatomic) IBOutlet UILabel *lblGoToUrl;
    @property (weak, nonatomic) IBOutlet UILabel *lblShortyUrl;
    @property (weak, nonatomic) IBOutlet UIBarButtonItem *btnSaveUrl;
    @property BOOL isEditable;
    - (IBAction)tapGoToUrl:(id)sender;
    - (IBAction)tapSaveUrl:(id)sender;
@end
