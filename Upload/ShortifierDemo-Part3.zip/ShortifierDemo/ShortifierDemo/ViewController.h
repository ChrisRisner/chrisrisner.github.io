//
//  ViewController.h
//  ShortifierDemo
//
//  Created by Chris Risner on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UrlDetailsViewController.h"

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, 
    UrlDetailsViewControllerDelegate, NSURLConnectionDelegate> {
@private
    BOOL _success;
    NSMutableData* receivedData;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end



