package com.msdpe.geodemo.misc;

import android.app.Application;
import android.location.Location;

public class GeoDemoApplication extends Application {
	private Location currentLocation;

	public Location getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(Location currentLocation) {
		this.currentLocation = currentLocation;
	}
	
	
}
