package com.msdpe.geodemo.misc;

public class Constants {
	//Preview
//	public static final String kFindPOIUrl = "http://demotest.antdf0.antares-test.windows-int.net/api/Location/FindPointsOfInterestWithinRadius";
//	public static final String kBlobSASUrl = "http://demotest.antdf0.antares-test.windows-int.net/api/blobsas/get?container=%s&blobname=%s";
//	public static final String kAddPOIUrl = "http://demotest.antdf0.antares-test.windows-int.net/api/location/postpointofinterest/";
	//Prod
	public static final String kFindPOIUrl = "http://locationservice.azurewebsites.net/api/Location/FindPointsOfInterestWithinRadius";
	public static final String kBlobSASUrl = "http://locationservice.azurewebsites.net/api/blobsas/get?container=%s&blobname=%s";
	public static final String kAddPOIUrl = "http://locationservice.azurewebsites.net/api/location/postpointofinterest/";
}
