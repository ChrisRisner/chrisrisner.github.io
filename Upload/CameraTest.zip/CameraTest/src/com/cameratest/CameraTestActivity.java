package com.cameratest;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CameraTestActivity extends Activity {
	
	Uri fileUri;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.i("CameraTestActivity", "onCreate");
        
        //Restore the fileURI since we might be recreating the activity
        if (savedInstanceState != null) {
        	fileUri = Uri.parse(savedInstanceState.getString("uri"));
        	
        }
        
        TextView lblLabelOne = (TextView) findViewById(R.id.lblLabelOne);
        
        /*
        Camera cam = Camera.open();
        android.hardware.Camera.Parameters camParameters =cam.getParameters();
        List<android.hardware.Camera.Size> sizes = camParameters.getSupportedPictureSizes();
        StringBuilder sb = new StringBuilder();
        for (Size picSize: sizes) {
        	//sb.append("height: " + picSize.height);
        	//sb.append("  Width: " + picSize.width);
        	sb.append("Resolution: " + (picSize.height * picSize.width));
        	sb.append("Megapixels: " + ((float) (picSize.height * picSize.width) / 1000000.0));
        	sb.append("Megapixels2: " + (((picSize.height * picSize.width) + 1000000 / 2) / 1000000));
        	sb.append("\n");
        }//
        
        if (sizes.size() > 0) 
        	lblLabelOne.setText(sb.toString());
        else
        	lblLabelOne.setText("NO CAMERAS");
        */
        
        
        if (CameraUtility.getSupportedMegapixelRatings().size() > 0) {
        		if (CameraUtility.doesSupport8MP())
        			lblLabelOne.setText("Supports 8 mp");
        		else if (CameraUtility.doesSupport5MP())
        			lblLabelOne.setText("Supports 5 mp");
        		else if (CameraUtility.doesSupport3MP())
        			lblLabelOne.setText("Supports 3 mp");
        		else if (CameraUtility.doesSupport2MP())
        			lblLabelOne.setText("Supports 2 mp");
        		 else
        	        	lblLabelOne.setText("All cameras are crappy");
        		
        }
        else
        	lblLabelOne.setText("NO CAMERAS");
        
        
        
        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				  try {
				// TODO Auto-generated method stub
				// create Intent to take a picture and return control to the calling application
			    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

			    //fileUri =  getOutputMediaFileUri(0); // create a file to save the image
			    
			   
					fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);
				Log.w("CameraTestActivity", "FileURI Before=" + fileUri.toString());
				
			    
			    intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri); // set the image file name

			    // start the image capture Intent
			    startActivityForResult(intent, 100);
				  } catch (IOException e) {
						// TODO Auto-generated catch block
						Log.e("CameraTestActivity", "Exception");
					}
			}
		});
        	
    }
    
    
    //This can be called when we go to the camera (i.e. our activity can die so we might need this)
    @Override
    protected void onSaveInstanceState(Bundle outState) {
    	// TODO Auto-generated method stub
    	outState.putString("uri", fileUri.toString());
    	super.onSaveInstanceState(outState);
    	Log.i("CameraTestActivity", "onsaveInstanceState");
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	// TODO Auto-generated method stub//
    	if (fileUri == null)
    		Log.w("CameraTestActivity", "FILE URI After is null");
    	else
    		Log.w("CameraTestActivity", "FILE URI After is null=" + fileUri.toString() );
    	Log.i("CameraTestActivity", "resultcode = " + resultCode);
    	if (requestCode == 100) {
    		if (resultCode == RESULT_OK) {
                // Image captured and saved to fileUri specified in the Intent
    			if (data == null)
    				Log.w("CameraTestActivity", "Data is null");
//    			for (String key : data.getExtras().keySet()) {
//    				Log.w("CameraTestActivity", key);
//    			}
    			
    			//http://developer.android.com/guide/topics/media/camera.html
    			//Use fileURI becuase at least for some devices, the data returned is NULL!
                Toast.makeText(this, "Image saved to:\n" +
                		fileUri.toString(), Toast.LENGTH_LONG).show();
                         //data.getData(), Toast.LENGTH_LONG).show();
            } else if (resultCode == RESULT_CANCELED) {
            	Toast.makeText(this, "Usr canceled", Toast.LENGTH_LONG).show();
            } else {
            	Toast.makeText(this, "Fail whale", Toast.LENGTH_LONG).show();
            }
    	}
    }
    
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;

    /** Create a file Uri for saving an image or video 
     * @throws IOException */
    private static Uri getOutputMediaFileUri(int type) throws IOException{
          return Uri.fromFile(getOutputMediaFile(type));
    }

    /** Create a File for saving an image or video 
     * @throws IOException */
    private static File getOutputMediaFile(int type) throws IOException{
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
    	Log.i("CameraTestActivity", "getOutputMediaFIle 1");
    	
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                  Environment.DIRECTORY_PICTURES), "MyCameraApp");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.
        Log.i("CameraTestActivity", "getOutputMediaFIle 2");
        // Create the storage directory if it does not exist
        if (! mediaStorageDir.exists()){
        	Log.i("CameraTestActivity", "getOutputMediaFIle 3");
            if (! mediaStorageDir.mkdirs()){
            	Log.i("CameraTestActivity", "getOutputMediaFIle 4");
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        Log.i("CameraTestActivity", "type = " + MEDIA_TYPE_IMAGE);
        if (type == MEDIA_TYPE_IMAGE){
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
            "IMG_"+ timeStamp + ".jpg");
            Log.e("CameraTestActivity", mediaStorageDir.getPath() + File.separator +"IMG_"+ timeStamp + ".jpg");
        } else if(type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
            "VID_"+ timeStamp + ".mp4");
        } else {
            return null;
        }
        if (mediaFile.exists() == false) {
        	mediaFile.getParentFile().mkdirs();
        	mediaFile.createNewFile();
        }
        return mediaFile;
    }
}