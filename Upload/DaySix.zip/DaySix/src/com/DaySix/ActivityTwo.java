package com.DaySix;

import android.app.Activity;
import android.os.Bundle;

public class ActivityTwo extends BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.second_layout);
	}
}
