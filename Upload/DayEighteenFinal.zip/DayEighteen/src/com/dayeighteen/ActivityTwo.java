package com.dayeighteen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Display;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class ActivityTwo extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);	
		setContentView(R.layout.second_layout);
		
		WebView webView1 = (WebView) findViewById(R.id.webView1);
		
		//Send all link clicks to our custom AppWebViewClient
		//webView1.setWebViewClient(new AppWebViewClient());

		//Send all link clicks through the web view
		//webView1.setWebViewClient(new WebViewClient());
		
		//webView1.loadUrl("http://www.google.com");

		
		//Load our local file
		webView1.loadUrl("file:///android_asset/webapp.html");
		
		//Turns on JavaScript and loads our local HTML page
		//WebSettings settings = webView1.getSettings();
		//settings.setJavaScriptEnabled(true);
		//webView1.addJavascriptInterface(new AppJavaScriptInterface(this), "Android");			
		//webView1.loadUrl("file:///android_asset/webapp.html");
	}	
	
	private class AppWebViewClient extends WebViewClient {
	    @Override
	    public boolean shouldOverrideUrlLoading(WebView view, String url) {	    	
	        if (Uri.parse(url).getHost().equals("www.google.com")) {
	            // This is a google site, keep it in the web view
	            return false;
	        }
	        // If we're not going to google, launch whatever activity will handle this url
	        Intent urlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
	        startActivity(urlIntent);
	        return true;
	    }
	}
	
	/**
	 * This handles the back button press pre 2.0
	 */
//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		WebView webView1 = (WebView) findViewById(R.id.webView1);
//		// If the key was back and there is history in the web view, go back
//	    if ((keyCode == KeyEvent.KEYCODE_BACK) && webView1.canGoBack()) {
//	    	webView1.goBack();
//	        return true;
//	    }
//	    //Handle anything else
//	    return super.onKeyDown(keyCode, event);
//	}
	
	/**
	 * 2.0 and greater can use this to handle back
	 */
	@Override
	public void onBackPressed() {
		WebView webView1 = (WebView) findViewById(R.id.webView1);
		// If there is history in the web view, go back
	    if (webView1.canGoBack()) {
	    	webView1.goBack();
	        return;
	    }
	    //Handle anything else
	    super.onBackPressed();
	}
}
