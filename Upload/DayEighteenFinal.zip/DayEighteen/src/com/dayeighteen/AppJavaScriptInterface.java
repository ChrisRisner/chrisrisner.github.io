package com.dayeighteen;

import android.content.Context;
import android.widget.Toast;

public class AppJavaScriptInterface {
	private Context context;

    public AppJavaScriptInterface(Context context) {
        this.context = context;
    }

    public void showToast(String text) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
    }
}
