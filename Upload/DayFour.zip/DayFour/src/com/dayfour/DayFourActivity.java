package com.dayfour;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DayFourActivity extends Activity {
	private TextView lblTextViewOne;
	private EditText editText1;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        lblTextViewOne = (TextView) findViewById(R.id.lblTextViewOne);
        lblTextViewOne.setText(R.string.test_one);//
        
        editText1 = (EditText) findViewById(R.id.editText1);
        editText1.setText(R.string.test_one);
        
        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {
				lblTextViewOne.setText(editText1.getText());				
			}
		});
    }
}